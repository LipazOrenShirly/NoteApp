import 'react-native-gesture-handler';
import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity} from 'react-native';
import { Button, ThemeProvider, Icon } from 'react-native-elements';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

class Note extends Component {
    constructor(props){
        super(props);
        this.state = {
            id: this.props.note.id,
            text: this.props.note.text,
            category: this.props.note.category,
            image: this.props.note.image,
            note: this.props.note
        };
        let local = true;
        this.apiUrl = 'http://localhost:55299/api/Note';
        if (!local) {
            this.apiUrl = 'proj.ruppin.ac.il/igroup2/mobile/server/api/Note';
        }
    }

    deleteNote = () => {
        console.log("note= "+this.state.id);
        this.props.sendData(this.state.id);
    }

    render() {
        return (
            <ThemeProvider>
                <View style={styles.viewStyle}>
                    <Text style={styles.textStyle}> 
                    {this.state.text}  
                        <Icon name='delete' onPress = {this.deleteNote} />
                    </Text>             
                </View>
            </ThemeProvider>
        );
    }
}

export default Note;

const styles = StyleSheet.create({
    container:{
      flex:1,
      backgroundColor: "#b3e5fc",
      alignItems: 'center',
    },
    textStyle:{
        alignItems: 'center',
        borderColor: "white",
        fontSize: 30,
        color: "blue",
    },
    headerStyle:{
      fontSize: 30,
      color: "white",
      fontWeight:"bold",
      alignItems: 'center',
      marginBottom:10
    },
    viewStyle: {
      marginTop:30,
      margin: 10,
    },
    inputStyle:{
      height: 40,
      borderColor: "white",
      borderWidth:1,
    },
    todo:{
      fontSize:24,
      color:"white"
    },
    styleImg:{
      flex: 0.35,
    }
  });