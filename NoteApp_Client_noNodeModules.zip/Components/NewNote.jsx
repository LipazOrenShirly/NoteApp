import 'react-native-gesture-handler';
import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity} from 'react-native';
import { Button, ThemeProvider } from 'react-native-elements';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

class NewNote extends Component {
    constructor(props){
        super(props);
        this.state = {
            category: this.props.route.params.category,
            noteText: ""
        };
        let local = true;
        this.apiUrl = 'http://localhost:55299/api/Note';
        if (!local) {
        this.apiUrl = 'proj.ruppin.ac.il/igroup2/mobile/server/api/Note';
        }
    }

    addNote = () => {
        console.log(this.state.noteText)
        const data = {
        Category: this.state.category,
        Text: this.state.noteText,
        Image: ""
        };

        fetch(this.apiUrl, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: new Headers({
                'Content-type': 'application/json; charset=UTF-8' //very important to add the 'charset=UTF-8'!!!!
            })
        })
        .then(res => {
            console.log('res=', res);
            return res.json()
        })
        .then(
            (result) => {
            console.log("fetch POST= ", result);
            console.log(result);
            },
            (error) => {
            console.log("err post=", error);
        })
        .then(()=>{
            this.props.navigation.navigate('Notes',{ navigation: this.props.navigation, category: this.state.category })
        }
        )
        .then(()=>{
            this.props.route.params.sendDataToAdd(this.state.noteText, this.state.category)
        });
    }

    render() {
        return (
            <ThemeProvider>
                <View  style={styles.container}>
                    <Text style={styles.headerStyle}>Adding New Note</Text>
                    <Text style={styles.textStyle}>Category: {this.state.category}</Text>
                    <TextInput 
                        style={styles.inputStyle}
                        onChangeText = {(text) => this.setState({noteText: text})}
                    />
                    <Button 
                        title="Add"
                        onPress={this.addNote}
                    />
                </View>
            </ThemeProvider>
        );
    }
}

export default NewNote;

  const styles = StyleSheet.create({
    container:{
      flex:1,
      backgroundColor: "#b3e5fc",
      alignItems: 'center',
    },
    inputStyle:{
        height: 40,
        borderColor: "white",
        borderWidth:1,
    },
    headerStyle:{
      fontSize: 30,
      color: "white",
      fontWeight:"bold",
      alignItems: 'center',
      marginBottom:10
    },
    viewStyle: {
      marginTop:30,
      margin: 10,
    },
    inputStyle:{
      height: 40,
      borderColor: "white",
      borderWidth:1,
    },
    textStyle:{
      fontSize:20,
      color:"#3f51b5"
    },
    styleImg:{
      flex: 0.35,
    }
  });