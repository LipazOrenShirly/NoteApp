import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity} from 'react-native';
import { Button, ThemeProvider } from 'react-native-elements';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';



class Category extends Component {
    constructor(props){
        super(props);
        this.state = {
           category: this.props.category
        };
    }

    render() {
        return (
            <ThemeProvider>
                <View>
                    <Button 
                        title={this.state.category.name + " ("+this.state.category.count+")"}
                        type="outline"
                        onPress={() => {
                            {console.log(this.props)}
                            this.props.navigation.navigate('Notes',{ navigation: this.props.navigation, category: this.state.category.name })
                        }}/>
                </View>
            </ThemeProvider>
        );
    }
}

export default Category;

const styles = StyleSheet.create({
    container:{
      flex:1,
      backgroundColor: "#b3e5fc",
      alignItems: 'center',
    },
    headerStyle:{
      fontSize: 30,
      color: "white",
      fontWeight:"bold",
      alignItems: 'center',
      marginBottom:10
    },
    viewStyle: {
      marginTop:30,
      margin: 10,
    },
    inputStyle:{
      height: 40,
      borderColor: "white",
      borderWidth:1,
    },
    todo:{
      fontSize:24,
      color:"white"
    },
    styleImg:{
      flex: 0.35,
    }
  });