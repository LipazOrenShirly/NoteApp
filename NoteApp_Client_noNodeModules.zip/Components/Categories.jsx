import 'react-native-gesture-handler';
import React, {Component} from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, ImageBackground} from 'react-native';
import { Button, ThemeProvider, Input } from 'react-native-elements';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack'; 
import Notes from './Notes'; 
import Category from './Category';

var imgSrc = require('../assets/Logo1.jpg');

class Categories extends Component{
    constructor(props){
        super(props);
        this.state = {
            categories: [],
            newCategory: "",
        };
        let local = true;
        this.apiUrl = 'http://localhost:55299/api/Category';
        if (!local) {
            this.apiUrl = 'proj.ruppin.ac.il/igroup2/mobile/server/api/Category';
        }
    }

    componentWillMount() {
        fetch(this.apiUrl, {
          method: 'GET',
          headers: new Headers({
            'Content-Type': 'application/json; charset=UTF-8',
          })
        })
          .then(res => {
            console.log('res=', res);
            console.log('res.status', res.status);
            console.log('res.ok', res.ok);
            return res.json()
          })
          .then(
            (result) => {
              console.log("fetch getCategories= ", result);
              result.map(cat => console.log(cat.name));
              console.log('result[0].Name=', result[0].name);
              this.setState({categories: result});
            },
            (error) => {
              console.log("err GET=", error);
            });
    }

    addCategory = () => {
        console.log(this.state.newCategory)
        const data = {
        Name: this.state.newCategory 
        };

        fetch(this.apiUrl, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: new Headers({
                'Content-type': 'application/json; charset=UTF-8' //very important to add the 'charset=UTF-8'!!!!
            })
        })
        .then(res => {
            console.log('res=', res);
            return res.json()
        })
        .then(
            (result) => {
            console.log("fetch POST= ", result);
            console.log(result);
            },
            (error) => {
            console.log("err post=", error);
        })
        .then(()=>{ 
          var newCat = {name: this.state.newCategory, count: 0};
          var arr = this.state.categories;
          arr.push(newCat);
          this.setState({categories: arr});
        })
        .then(()=>{
          this.setState({newCategory: ""});
        });


    }

    render(){
        return(
        <ThemeProvider>
            <View style={styles.container}>
                <View>
                    <Image source={imgSrc} style={styles.styleImg}/>
                </View>
                <View style={styles.viewStyle}>
                    <Text style={styles.headerStyle}>Add New Category</Text>
                    <TextInput 
                        style={styles.inputStyle}
                        onChangeText = {(text) => this.setState({newCategory: text})}
                        value = {this.state.newCategory}
                    />
                    <Button 
                        title="Add"
                        onPress={this.addCategory}
                    />
                    <View style={{marginTop:50}}/>
                    <Text style={styles.headerStyle}>My Categories :</Text>
                    {this.state.categories.map((cat,key)=>
                        <Category index={key} category={cat} navigation={this.props.navigation} />
                    )}
                </View>
            </View>
        </ThemeProvider>
        )
    }
}

export default Categories;

const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor: "#b3e5fc",
    alignItems: 'center',
  },
  headerStyle:{
    fontSize: 30,
    color: "white",
    fontWeight:"bold",
    alignItems: 'center',
    marginBottom:10
  },
  viewStyle: {
    marginTop:30,
    margin: 10,
  },
  inputStyle:{
    height: 40,
    borderColor: "white",
    borderWidth:1,
  },
  todo:{
    fontSize:24,
    color:"white"
  },
  styleImg:{
    flex: 0.35,
  }
});


