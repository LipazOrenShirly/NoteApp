import 'react-native-gesture-handler';
import React, { Component } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity} from 'react-native';
import { Button, ThemeProvider } from 'react-native-elements';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import Note from './Note';

class Notes extends Component {
    constructor(props){
        super(props);
        this.state = {
            category: this.props.route.params.category != undefined ? this.props.route.params.category : "",
            notes: []
        };
        let local = true;
        this.apiUrl = 'http://localhost:55299/api/Note';
        if (!local) {
            this.apiUrl = 'proj.ruppin.ac.il/igroup2/mobile/server/api/Note';
        }
    }

    componentWillMount() {
        fetch(this.apiUrl, {
          method: 'GET',
          headers: new Headers({
            'Content-Type': 'application/json; charset=UTF-8',
          })
        })
          .then(res => {
            console.log('res=', res);
            console.log('res.status', res.status);
            console.log('res.ok', res.ok);
            return res.json()
          })
          .then(
            (result) => {
              console.log("fetch getCategories= ", result);
              result.map(note => console.log(note.text));
              console.log('result[0].Name=', result[0].text);
              this.setState({notes: result.filter(note => note.category == this.state.category)});
            },
            (error) => {
              console.log("err post=", error);
            });
    }

    getDataToAdd = (noteText, noteCat) => {
      var arr = this.state.notes;
      var newNote = {category: noteCat, text: noteText};
      arr.push(newNote);
      this.setState({notes: arr});
    }

    getData = (idToDel) => {
        this.setState((prevState) => ({notes: prevState.notes.filter(note => note.id != idToDel)}));
        console.log("idToDel="+idToDel);
        const data = {
          Id: idToDel
        };
        console.log("data = "+JSON.stringify(data));

        fetch(this.apiUrl, {
            method: 'DELETE',
            body: JSON.stringify(data),
            headers: new Headers({
              'Content-type': 'application/json; charset=UTF-8' //very important to add the 'charset=UTF-8'!!!!
            })      
          })
            .then(res => {
              console.log('res=', res);
              return res.json()
            })
            .then(
              (result) => {
                console.log("fetch DELETE= ", result);
              },
              (error) => {
                console.log("err DELETE=", error);
              });
    }

    render() {
        return (
          <ThemeProvider>
            <View style={styles.container}>
              <Text style={styles.headerStyle}>{this.state.category}</Text>
              <Button 
                title = "Add New Note"
                type="outline"
                onPress={() =>
                    {this.props.navigation.navigate('NewNote',
                    { navigation: this.props.navigation, 
                      category: this.state.category, 
                      sendDataToAdd: this.getDataToAdd }
                    )}
                }/>
                {this.state.notes.map((note,key)=>
                <Note index={key} note={note} navigation={this.props.navigation} sendData={this.getData} />
                )}
            </View>
          </ThemeProvider>
        );
    }
}

export default Notes;

const styles = StyleSheet.create({
  container:{
    flex:1,
    backgroundColor: "#b3e5fc",
    alignItems: 'center',
  },
  headerStyle:{
    fontSize: 30,
    color: "white",
    fontWeight:"bold",
    alignItems: 'center',
    marginBottom:10
  },
  viewStyle: {
    marginTop:30,
    margin: 10,
  },
  inputStyle:{
    height: 40,
    borderColor: "white",
    borderWidth:1,
  },
  todo:{
    fontSize:24,
    color:"white"
  },
  styleImg:{
    flex: 0.35,
  }
});