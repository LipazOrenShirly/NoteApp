import 'react-native-gesture-handler';
import React, {Component} from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Image, ImageBackground} from 'react-native';
import { Button, ThemeProvider, Input } from 'react-native-elements';
import Categories from './Components/Categories';
import Notes from './Components/Notes';
import NewNote from './Components/NewNote';


import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack'; 

const Stack = createStackNavigator();

class App extends Component{
  
  constructor(props){
    super(props);
    this.state = {
    };
  }

  render(){
    return(
          <NavigationContainer>
            <Stack.Navigator initialRouteName="Categories">
              <Stack.Screen name="Categories" component={Categories} />
              <Stack.Screen name="Notes" component={Notes} />
              <Stack.Screen name="NewNote" component={NewNote} />
            </Stack.Navigator>
          </NavigationContainer>
    )
  }
}

export default App;




